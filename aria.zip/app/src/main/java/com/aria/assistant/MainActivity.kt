package com.aria.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class ChatMsg(val fromUser: Boolean, val text: String)

class ConfirmRequest(val message: String, val result: CompletableDeferred<Boolean>)

class MainActivity : ComponentActivity() {

    private lateinit var settings: Settings
    private lateinit var agent: Agent
    private lateinit var voice: Voice

    private val chat = mutableStateListOf<ChatMsg>()
    private var status by mutableStateOf("Tap the mic and speak")
    private var partial by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var listening by mutableStateOf(false)
    private var confirmRequest by mutableStateOf<ConfirmRequest?>(null)
    private var showSettings by mutableStateOf(false)
    private var job: Job? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) voice.startListening() else status = "Microphone permission denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        settings = Settings(this)
        val tools = Tools(this) { message -> askConfirm(message) }
        agent = Agent(settings, tools)
        voice = Voice(
            this,
            onPartialText = { partial = it },
            onFinalText = { partial = ""; submit(it) },
            onProblem = { partial = ""; status = it },
            onListening = { listening = it; if (it) status = "Listening…" }
        )

        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Screen()
                }
            }
        }
    }

    override fun onDestroy() {
        voice.shutdown()
        super.onDestroy()
    }

    // ---- actions ----

    /** Confirmation is always a tap on screen, never a voice command. */
    private suspend fun askConfirm(message: String): Boolean {
        val req = ConfirmRequest(message, CompletableDeferred())
        confirmRequest = req
        voice.speak("Please confirm on screen.")
        try {
            return req.result.await()
        } finally {
            confirmRequest = null
        }
    }

    private fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        if (settings.apiKey.isBlank()) {
            showSettings = true
            return
        }
        chat.add(ChatMsg(true, t))
        busy = true
        status = "Thinking…"
        job = lifecycleScope.launch {
            try {
                val reply = agent.ask(t)
                chat.add(ChatMsg(false, reply))
                voice.speak(reply.replace(Regex("[*_#`]"), ""))
                status = "Tap the mic and speak"
            } catch (e: CancellationException) {
                chat.add(ChatMsg(false, "Stopped."))
                status = "Stopped"
                throw e
            } catch (e: Exception) {
                chat.add(ChatMsg(false, "Error: ${e.message}"))
                status = "Something went wrong"
            } finally {
                busy = false
            }
        }
    }

    private fun stopAll() {
        job?.cancel()
        voice.stopSpeaking()
        voice.stopListening()
        partial = ""
    }

    private fun onMic() {
        if (busy) {
            stopAll()
            return
        }
        if (listening) {
            voice.finishListening()
            return
        }
        if (settings.apiKey.isBlank()) {
            showSettings = true
            return
        }
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) voice.startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    // ---- UI ----

    @Composable
    private fun Screen() {
        LaunchedEffect(Unit) {
            if (settings.apiKey.isBlank()) showSettings = true
        }
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Aria", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { stopAll(); agent.reset(); chat.clear(); status = "New conversation" }) {
                    Text("New chat")
                }
                TextButton(onClick = { showSettings = true }) { Text("Settings") }
            }

            val listState = rememberLazyListState()
            LaunchedEffect(chat.size) {
                if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1)
            }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chat) { m -> Bubble(m) }
            }

            Text(
                if (partial.isNotEmpty()) partial else status,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            var text by remember { mutableStateOf("") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type, or tap the mic") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { submit(text); text = "" })
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { onMic() },
                    modifier = Modifier.size(64.dp),
                    shape = CircleShape,
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (listening) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(if (busy) "■" else if (listening) "●" else "🎤", fontSize = 26.sp)
                }
            }
        }

        confirmRequest?.let { req ->
            AlertDialog(
                onDismissRequest = { req.result.complete(false) },
                title = { Text("Confirm action") },
                text = { Text(req.message) },
                confirmButton = { TextButton(onClick = { req.result.complete(true) }) { Text("Confirm") } },
                dismissButton = { TextButton(onClick = { req.result.complete(false) }) { Text("Cancel") } }
            )
        }

        if (showSettings) {
            var key by remember { mutableStateOf(settings.apiKey) }
            var web by remember { mutableStateOf(settings.webSearch) }
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Settings") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = key,
                            onValueChange = { key = it },
                            label = { Text("Claude API key") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                        Spacer(Modifier.size(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = web, onCheckedChange = { web = it })
                            Spacer(Modifier.width(8.dp))
                            Text("Web search")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        settings.apiKey = key
                        settings.webSearch = web
                        showSettings = false
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
            )
        }
    }

    @Composable
    private fun Bubble(m: ChatMsg) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
        ) {
            Surface(
                modifier = Modifier.widthIn(max = 300.dp),
                shape = RoundedCornerShape(16.dp),
                color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Text(m.text, Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
            }
        }
    }
}
