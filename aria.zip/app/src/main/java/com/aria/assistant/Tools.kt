package com.aria.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * GREEN = runs automatically (read-only or harmless; anything that sends/calls only opens a draft).
 * AMBER = the user must tap Confirm on screen first (enforced in code, not by the AI).
 * RED   = always blocked.
 */
enum class Risk { GREEN, AMBER, RED }

class Tool(
    val name: String,
    val description: String,
    val schema: JSONObject,
    val risk: Risk,
    val confirmMsg: String? = null,
    val run: suspend (JSONObject) -> String
)

private fun schema(required: List<String>, vararg props: Triple<String, String, String>): JSONObject {
    val p = JSONObject()
    for ((name, type, desc) in props) {
        p.put(name, JSONObject().put("type", type).put("description", desc))
    }
    return JSONObject()
        .put("type", "object")
        .put("properties", p)
        .put("required", JSONArray(required))
}

class Tools(
    private val ctx: Context,
    private val confirm: suspend (String) -> Boolean
) {
    val all: List<Tool> = listOf(
        Tool(
            "open_app", "Open an installed app by name.",
            schema(listOf("app_name"), Triple("app_name", "string", "App name as shown on the phone, e.g. Chrome or WhatsApp")),
            Risk.GREEN
        ) { openApp(it) },
        Tool(
            "open_url", "Open a web page (http or https) in the browser.",
            schema(listOf("url"), Triple("url", "string", "Full URL starting with https://")),
            Risk.GREEN
        ) { openUrl(it) },
        Tool(
            "set_alarm", "Set an alarm for the next occurrence of a clock time (within 24 hours).",
            schema(
                listOf("hour", "minute"),
                Triple("hour", "integer", "Hour in 24-hour format, 0-23"),
                Triple("minute", "integer", "Minute, 0-59"),
                Triple("label", "string", "Short label for the alarm")
            ),
            Risk.GREEN
        ) { setAlarm(it) },
        Tool(
            "set_timer", "Start a countdown timer.",
            schema(
                listOf("seconds"),
                Triple("seconds", "integer", "Duration in seconds"),
                Triple("label", "string", "Short label for the timer")
            ),
            Risk.GREEN
        ) { setTimer(it) },
        Tool(
            "save_note", "Save a note in the assistant's private notes.",
            schema(
                listOf("text"),
                Triple("title", "string", "Short title"),
                Triple("text", "string", "Note content")
            ),
            Risk.GREEN
        ) { saveNote(it) },
        Tool(
            "list_notes", "Read back the saved notes.",
            schema(emptyList()),
            Risk.GREEN
        ) { listNotes() },
        Tool(
            "delete_all_notes", "Permanently delete ALL saved notes.",
            schema(emptyList()),
            Risk.AMBER,
            "Delete ALL saved notes? This cannot be undone."
        ) { deleteNotes() },
        Tool(
            "add_calendar_event", "Open the calendar with a prefilled event. The user taps Save in the calendar app.",
            schema(
                listOf("title", "start"),
                Triple("title", "string", "Event title"),
                Triple("start", "string", "Local start time, ISO format like 2026-09-30T15:00:00"),
                Triple("end", "string", "Local end time, same format. Optional, defaults to 1 hour."),
                Triple("description", "string", "Optional details")
            ),
            Risk.GREEN
        ) { addEvent(it) },
        Tool(
            "draft_email", "Open the email app with a prefilled draft. The user reviews and presses send.",
            schema(
                listOf("subject", "body"),
                Triple("to", "string", "Recipient email address, if known"),
                Triple("subject", "string", "Subject line"),
                Triple("body", "string", "Email body")
            ),
            Risk.GREEN
        ) { draftEmail(it) },
        Tool(
            "draft_sms", "Open the messaging app with a prefilled text message. The user presses send.",
            schema(
                listOf("number", "message"),
                Triple("number", "string", "Phone number"),
                Triple("message", "string", "Message text")
            ),
            Risk.GREEN
        ) { draftSms(it) },
        Tool(
            "dial_number", "Open the phone dialer with a number. The user presses call.",
            schema(listOf("number"), Triple("number", "string", "Phone number")),
            Risk.GREEN
        ) { dial(it) }
    )

    fun definitions(): JSONArray {
        val arr = JSONArray()
        for (t in all) {
            arr.put(
                JSONObject()
                    .put("name", t.name)
                    .put("description", t.description)
                    .put("input_schema", t.schema)
            )
        }
        return arr
    }

    /** The safety gate: every tool call from the AI passes through here. */
    suspend fun execute(name: String, input: JSONObject): String {
        val tool = all.find { it.name == name } ?: return "Error: unknown tool $name"
        if (tool.risk == Risk.RED) {
            audit(name, input, "BLOCKED")
            return "Blocked: this action is not allowed."
        }
        if (tool.risk == Risk.AMBER) {
            val ok = confirm(tool.confirmMsg ?: "Allow ${tool.name}?")
            if (!ok) {
                audit(name, input, "DECLINED by user")
                return "The user declined this action. Do not retry it."
            }
        }
        val result = try {
            tool.run(input)
        } catch (e: Exception) {
            "Error: ${e.message ?: e.javaClass.simpleName}"
        }
        audit(name, input, result)
        return result
    }

    // ---- tool implementations ----

    private fun openApp(input: JSONObject): String {
        val q = input.getString("app_name").trim().lowercase()
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "No installed app matches \"$q\"."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "That app can't be launched."
        ctx.startActivity(intent)
        return "Opened ${match.loadLabel(pm)}."
    }

    private fun openUrl(input: JSONObject): String {
        val url = input.getString("url").trim()
        if (!url.startsWith("https://") && !url.startsWith("http://")) return "Only http(s) links are allowed."
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "Opened $url."
    }

    private fun setAlarm(input: JSONObject): String {
        val h = input.getInt("hour")
        val m = input.getInt("minute")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h)
            putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_MESSAGE, input.optString("label", "Aria"))
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        ctx.startActivity(intent)
        return "Alarm set for %02d:%02d.".format(h, m)
    }

    private fun setTimer(input: JSONObject): String {
        val s = input.getInt("seconds")
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, s)
            putExtra(AlarmClock.EXTRA_MESSAGE, input.optString("label", "Aria"))
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        ctx.startActivity(intent)
        return "Timer started for $s seconds."
    }

    private fun notesFile() = File(ctx.filesDir, "notes.txt")

    private fun saveNote(input: JSONObject): String {
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
        val title = input.optString("title", "Note")
        notesFile().appendText("[$stamp] $title\n${input.getString("text")}\n\n")
        return "Note saved."
    }

    private fun listNotes(): String {
        val f = notesFile()
        val t = if (f.exists()) f.readText() else ""
        return if (t.isBlank()) "No notes yet." else t.takeLast(4000)
    }

    private fun deleteNotes(): String {
        notesFile().delete()
        return "All notes deleted."
    }

    private fun millis(iso: String): Long =
        LocalDateTime.parse(iso.trim()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun addEvent(input: JSONObject): String {
        val start = millis(input.getString("start"))
        val endText = input.optString("end", "")
        val end = if (endText.isBlank()) start + 3_600_000L else millis(endText)
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, input.getString("title"))
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            putExtra(CalendarContract.Events.DESCRIPTION, input.optString("description", ""))
        }
        ctx.startActivity(intent)
        return "Calendar opened with the event. The user must tap Save."
    }

    private fun draftEmail(input: JSONObject): String {
        val to = input.optString("to", "")
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, input.getString("subject"))
            putExtra(Intent.EXTRA_TEXT, input.getString("body"))
        }
        ctx.startActivity(intent)
        return "Email draft opened. The user must review and press send."
    }

    private fun draftSms(input: JSONObject): String {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", input.getString("number"), null))
        intent.putExtra("sms_body", input.getString("message"))
        ctx.startActivity(intent)
        return "Message draft opened. The user must press send."
    }

    private fun dial(input: JSONObject): String {
        ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", input.getString("number"), null)))
        return "Dialer opened. The user must press call."
    }

    private fun audit(name: String, input: JSONObject, result: String) {
        try {
            val line = "${LocalDateTime.now()} | $name | $input | ${result.take(200).replace('\n', ' ')}\n"
            File(ctx.filesDir, "audit.log").appendText(line)
        } catch (_: Exception) {
        }
    }
}
